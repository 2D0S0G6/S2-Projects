#include <stdio.h>
#include <stdlib.h>

// Define the structure for a node in the doubly linked list
struct Node {
    int data;                 // Data stored in the node
    struct Node* previous;    // Pointer to the previous node
    struct Node* next;        // Pointer to the next node
    int count;                // Count of how many times the node is accessed
};

// Function to create a new node
struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node)); // Allocate memory for a new node
    if (newNode == NULL) { // Check if memory allocation failed
        printf("Memory allocation failed\n");
        exit(1); // Exit if allocation failed
    }
    newNode->data = data; // Set the data
    newNode->previous = NULL; // Initialize previous pointer
    newNode->next = NULL; // Initialize next pointer
    newNode->count = 1; // Initialize count
    return newNode; // Return the new node
}

// Function to move a node to the beginning of the list
void moveToBeginning(struct Node** head, struct Node* node) {
    if (node == *head) { // Check if the node is already at the beginning
        return; // Do nothing if it's already the head
    }

    // Update pointers to remove the node from its current position
    if (node->previous != NULL) {
        node->previous->next = node->next;
    }
    if (node->next != NULL) {
        node->next->previous = node->previous;
    }

    // Move the node to the beginning
    node->next = *head;
    if (*head != NULL) {
        (*head)->previous = node;
    }
    node->previous = NULL;
    *head = node;
}

// Function to find a node with specific data
struct Node* findNode(struct Node* head, int data) {
    while (head != NULL) { // Traverse the list
        if (head->data == data) { // Check if the current node has the data
            return head; // Return the node if found
        }
        head = head->next; // Move to the next node
    }
    return NULL; // Return NULL if the node is not found
}

// Function to insert a new node or increment the count if it already exists
void insertOrIncrementAtBeginning(struct Node** head, int data) {
    struct Node* node = findNode(*head, data); // Find the node with the given data
    if (node != NULL) { // If the node exists
        node->count++; // Increment the count
        moveToBeginning(head, node); // Move it to the beginning
    } else { // If the node does not exist
        struct Node* newNode = createNode(data); // Create a new node
        if (*head != NULL) {
            (*head)->previous = newNode;
        }
        newNode->next = *head; // Insert the new node at the beginning
        *head = newNode; // Update the head pointer
    }
}

// Function to delete a node with specific data
void deleteNode(struct Node** head, int data) {
    struct Node* node = findNode(*head, data); // Find the node with the given data
    if (node == NULL) { // If the node is not found
        printf("Element %d not found, nothing to delete\n", data);
        return; // Do nothing
    }

    // Update pointers to remove the node from the list
    if (node->previous != NULL) {
        node->previous->next = node->next;
    } else {
        *head = node->next;
    }

    if (node->next != NULL) {
        node->next->previous = node->previous;
    }

    printf("Deleting element %d\n", data);
    free(node); // Free the memory of the node
}

// Function to print the list to a file
void printListToFile(struct Node* head, FILE* file) {
    while (head != NULL) { // Traverse the list
        fprintf(file, "%d (accessed %d times),", head->data, head->count); // Print each node's data and count
        head = head->next; // Move to the next node
    }
    fprintf(file, "\n"); // Print a new line at the end
}

// Function to search for a node and update the list
void search(struct Node** head, int data) {
    struct Node* node = findNode(*head, data); // Find the node with the given data
    if (node != NULL) { // If the node is found
        printf("Element %d found with count %d\n", data, node->count);
        node->count++; // Increment the count
        moveToBeginning(head, node); // Move it to the beginning
    } else { // If the node is not found
        printf("Element %d not found, adding to list\n", data);
        struct Node* newNode = createNode(data); // Create a new node
        if (*head != NULL) {
            (*head)->previous = newNode;
        }
        newNode->next = *head; // Insert the new node at the beginning
        *head = newNode; // Update the head pointer
    }
}

int main() 
{
    struct Node* head = NULL; // Initialize the head of the list
    FILE* inputFile = fopen("selforg.dat", "r"); // Open the input file
    if (inputFile == NULL) { // Check if the file was opened successfully
        printf("Error opening input file\n");
        return 1; // Return an error code if the file could not be opened
    }
    int number;
    while (fscanf(inputFile, "%d", &number) == 1) { // Read numbers from the file
        insertOrIncrementAtBeginning(&head, number); // Insert or increment each number in the list
    }
    fclose(inputFile); // Close the input file

    // Example search calls
    search(&head, 5); // Search for the element 5
    search(&head, 10); // Search for the element 10

    // Example delete calls
    deleteNode(&head, 5); // Delete the element 5
    deleteNode(&head, 10); // Delete the element 10

    FILE* outputFile = fopen("output.txt", "w"); // Open the output file
    if (outputFile == NULL) { // Check if the file was opened successfully
        printf("Error opening output file\n");
        return 1; // Return an error code if the file could not be opened
    }
    fprintf(outputFile, "Doubly linked list: \n"); // Write a header to the output file
    printListToFile(head, outputFile); // Print the list to the output file
    fclose(outputFile); // Close the output file
    return 0; // Return 0 to indicate successful execution
}